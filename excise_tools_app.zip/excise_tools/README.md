# excise_tools

Excise duty & customs tools for ERPNext (Frappe app).

Contains an auditor-facing Script Report: **Alcohol Stock by Batch (Auditor)**.
